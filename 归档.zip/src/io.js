function socket_io(server) {
    var io = require('socket.io')(server);

    // io监听连接
    io.on('connection', function(socket) {
        socket.emit('news', { hello: 'world22' });
        socket.on('xiaoming', function(data) {
            console.log(data);
        });
    });
    
}

module.exports = socket_io;